# online-demo

[Fork on StackBlitz ⚡️](https://stackblitz.com/fork/vuepress-theme-hope)

## Docs Demo

- Preview: `npm run docs:dev`
- Build: `npm run docs:build`

## Blog Demo

- Preview: `npm run blog:dev`
- Build: `npm run blog:build`
