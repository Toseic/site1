---
home: true
layout: BlogHome
icon: home
title: Blog Home
heroImage: /logo.svg
heroText: The name of your blog
tagline: You can put your slogan here
heroFullScreen: true
projects:
  - icon: project
    name: project name
    desc: project detailed description
    link: https://your.project.link

  - icon: link
    name: link name
    desc: link detailed description
    link: https://link.address

  - icon: book
    name: book name
    desc: Detailed description of the book
    link: https://link.to.your.book

  - icon: article
    name: article name
    desc: Detailed description of the article
    link: https://link.to.your.article

  - icon: friend
    name: friend name
    desc: Detailed description of friend
    link: https://link.to.your.friend

  - icon: /logo.svg
    name: custom item
    desc: Detailed description of this custom item
    link: https://link.to.your.friend

footer: customize your footer text
---

This is a blog home page demo.

To use this layout, you should set both `layout: BlogHome` and `home: true` in the page front matter.

For related configuration docs, please see [blog homepage](https://theme-hope.vuejs.press/guide/blog/home/).
