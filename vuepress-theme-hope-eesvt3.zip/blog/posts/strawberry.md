---
icon: pen-to-square
date: 2022-01-11
category:
  - Fruit
  - Strawberry
tag:
  - red
  - small
---

# Strawberry

## Heading 2

Here is the content.

### Heading 3

Here is the content.
