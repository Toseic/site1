---
title: Guide
icon: lightbulb
---

## Highlight Features

### Bar

- [baz](bar/baz.md)
- ...

### Foo

- [ray](foo/ray.md)
- ...
