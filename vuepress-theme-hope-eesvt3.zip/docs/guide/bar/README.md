---
title: Bar feature
icon: lightbulb
---

## Introduction

We support bar feature, ...

## Details

- [baz](baz.md)
- ...
